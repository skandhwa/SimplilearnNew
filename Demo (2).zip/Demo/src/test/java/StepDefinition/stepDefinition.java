package StepDefinition;

import PageFactoryElements.LoginPage;
import Utilities.DriverInitialization;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class stepDefinition {
	
	LoginPage obj=new LoginPage(DriverInitialization.getDriver());
	
	@Before(order=0)     ///Global Before hooke
	public void display()
	{
		System.out.println("Hello Everyone I am Before Every Scenario More priority");
	}
	
	@Before (order=1)    ///Global Before hooke
	public void display7()
	{
		System.out.println("Hello Everyone I am Before Every Scenario Less Priority");
	}
	
	@After     ///Global Before hooke
	public void display8()
	{
		System.out.println("Hello Everyone I am Before Every Scenario");
	}
	
	@After
	public void display1()
	{
		System.out.println("Hello Everyone I am After Every scenario");
	}
	
	@Before("@First")       /////Local Before Hooks
	public void display3()
	{
		System.out.println("Hello Everyone I am Before First scenario");
	}
	
	@Before("Second")       /////Local Before Hooks
	public void display4()
	{
		System.out.println("Hello Everyone I am Before Second scenario");
	}
	
	@After("@Second")
	public void display5()
	{
		System.out.println("Hello Everyone I am After Second scenario");
	}
	
	
	@After("@First")       /////Local Before Hooks
	public void display6()
	{
		System.out.println("Hello Everyone I am After First scenario");
	}
	
	
	
	
	@Given("User opens the WebPage")
	public void user_opens_the_web_page() 
	{
	    System.out.println("Application Launched and working fine");
	}

	@Then("User Enters FirstName")
	public void user_enters_first_name() {
		
		obj.loginApplication();
		
	    
	}

	@Then("User Enters LastName")
	public void user_enters_last_name() {
		obj.loginApplicationlastname();
		
		
	    
	}
	
	
	@Then("User Enters {string}")
	public void user_enters(String address) 
	
		
		{
			obj.enterAddress(address);
		}
	
	
	@Given("User selects continents")
	public void user_selects_continents() {
	    obj.selectcountries();
	}
	
	@Given("User Selects gender")
	public void user_selects_gender() {
	  
		obj.selectgender();
	}
		
	    
	


	

}
