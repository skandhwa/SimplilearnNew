package Authentications;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import Payloaddata.PayloadNew;
import URI.ReqresURI;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class BearerTokenAuthenticationNew {
	
	@Test
	public void BearerToken()
	{
		String Authtoken="Bearer 7ac968f862016621556cb45521c66c10fe3012a9dba8f062e686df4cc8404e36";
		RequestSpecification req=new RequestSpecBuilder().setBaseUri(ReqresURI.BearerAuthURI).build();
		RequestSpecification res=given().spec(req).headers("Authorization",Authtoken).body(PayloadNew.AddBearerBody());
		ResponseSpecification respec=new ResponseSpecBuilder().build();
		
		Response response=res.when().post().then().spec(respec).extract().response();
		
		String responseString=response.asString();
		System.out.println(responseString);
		
	}

}
