package Authentications;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import URI.ReqresURI;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class BasicAuth {
	
	@Test
	public void TestbasicAuth()
	{
		RequestSpecification req=new RequestSpecBuilder().setBaseUri(ReqresURI.BasicAuthURI).build();
		RequestSpecification res=given().spec(req).auth().basic("postman", "password");
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200).build();
		
		Response response=res.when().post().then().spec(respec).extract().response();
		
		String responseString=response.asString();
		System.out.println(responseString);
		
		
	}

}
