package Authentications;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import URI.ReqresURI;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class DigestAuthentication {
	
	@Test
	public void digestAuthentication()
	{
		RequestSpecification req=new RequestSpecBuilder().setBaseUri(ReqresURI.DigestAuthURI).build();
		RequestSpecification res=given().spec(req).auth().digest("saurabh","saurabh");
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200).build();
		
		Response response=res.when().get().then().spec(respec).extract().response();
		
		String responseString=response.asString();
		System.out.println(responseString);
	}

}
