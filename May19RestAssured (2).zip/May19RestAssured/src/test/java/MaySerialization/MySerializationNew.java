package MaySerialization;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import May21POJO.MAYPOJO;
import URI.ReqresURI;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.given;

public class MySerializationNew {
	
	@Test
	public void Employee() throws JsonProcessingException
	{
		MAYPOJO emp=new MAYPOJO();
		emp.setName("manish agarwal");
		emp.setJob("Manager");
		emp.setLocation("Kolkata");
		emp.setSalary(4000);
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJson=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
		System.out.println(empJson);
		
		RequestSpecification req=new RequestSpecBuilder().setBaseUri(ReqresURI.baseURI).build();
		RequestSpecification res=given().spec(req).body(empJson);
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(201).build();
		
		Response response=res.when().post().then().spec(respec).extract().response();
		
		String responseString=response.asString();
		System.out.println(responseString);
		
		
		
		
		System.out.println("----------DOING DESERIALIZATION---------------------");
		
		
		MAYPOJO emp2=obj.readValue(empJson, MAYPOJO.class);
//	String	empName=emp2.getName();
//	
//	if(empName=="manish")
//		System.out.println("Test case passed");
		
		System.out.println(emp2.getName());
		System.out.println(emp2.getJob());
		System.out.println(emp2.getLocation());
		System.out.println(emp2.getSalary());
		
		
		
		
		
		
		
		
	}
	
	

}
