package URI;

public class ReqresURI {
	
	public static final String baseURI="https://reqres.in/api/users";
	public static final String baseURIDelete="https://reqres.in/api/users/2";
	public static final String baseURIbin="http://httpbin.org/post";
	public static final String GoRestURI="https://gorest.co.in/public/v2/users";
	public static final String BasicAuthURI="http://postman-echo.com/basic-auth";
	public static final String DigestAuthURI="http://httpbin.org/digest-auth/undefined/saurabh/saurabh";
	public static final String BearerAuthURI="https://gorest.co.in/public/v2/users";
	
}
