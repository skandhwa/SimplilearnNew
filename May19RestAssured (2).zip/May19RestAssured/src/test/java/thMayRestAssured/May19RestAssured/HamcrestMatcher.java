package thMayRestAssured.May19RestAssured;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import static org.hamcrest.Matchers.*;

public class HamcrestMatcher {

	public static void main(String[] args) {
		
       RestAssured.baseURI="https://reqres.in/api/users";
		
	String Response=	given().log().all().when().get().then().body("page",equalTo(1)).body("data[0].id",equalTo(1))
		.body("data[2].first_name", containsString("Emma")).body("statuscode",equalTo(200)).extract().response().asString();
	
	System.out.println(Response);
	}

}
