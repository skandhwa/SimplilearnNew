package thMayRestAssured.May19RestAssured;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import org.testng.Assert;
import org.testng.asserts.*;

import static io.restassured.RestAssured.given;



public class MyFirstRestScript {

	public static void main(String[] args) {
		
		int page=1;
		String emailFirst="george.bluth@reqres.in";
		String Surname_first="Weaver";
		
		RestAssured.baseURI="https://reqres.in/api/users";
		
		String Response=given().log().all().headers("Connection","keep-alive")
		.when().get()
		.then().statusCode(200).header("Server","cloudflare").extract().response().asString();
		
		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
		
		int pagenumber=js.getInt("page");
		System.out.println(pagenumber);
		
		Assert.assertEquals(page, pagenumber);
		System.out.println("My page number validation is passed");
		
		String Email_Id=js.getString("data[0].email");
		Assert.assertEquals(emailFirst, Email_Id);
		System.out.println("My Email ID validation  is passed");
		
		String lastName=js.getString("data[1].last_name");
		Assert.assertEquals(lastName, Surname_first);
		System.out.println("My Name validation  is passed");
		
		
		
		
		

	}

}
