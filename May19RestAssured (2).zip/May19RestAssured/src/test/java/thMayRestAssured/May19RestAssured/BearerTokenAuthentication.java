package thMayRestAssured.May19RestAssured;

import static io.restassured.RestAssured.given;

import Payloaddata.PayloadNew;
import URI.ReqresURI;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class BearerTokenAuthentication {

	public static void main(String[] args) {
		
		String AuthToken="Bearer 7ac968f862016621556cb45521c66c10fe3012a9dba8f062e686df4cc8404e36";
		
	RequestSpecification req=new RequestSpecBuilder().setBaseUri(ReqresURI.GoRestURI).setContentType(ContentType.JSON).build();
		
		RequestSpecification res=given().spec(req).headers("Authorization",AuthToken).
				body(PayloadNew.AddDetailsGoRest()).queryParam("appid","");
		
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(201)
				.expectContentType(ContentType.JSON).build();
		
		
		Response response=  res.when().post().then().spec(respec).extract().response();
		
		String responseString=response.asString();
		
		System.out.println(responseString);
		
		JsonPath js=new JsonPath(responseString);
		
		

	}

}
