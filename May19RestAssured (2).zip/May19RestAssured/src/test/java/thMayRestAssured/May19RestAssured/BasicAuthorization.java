package thMayRestAssured.May19RestAssured;

import static io.restassured.RestAssured.given;
import org.testng.annotations.Test;

import URI.ReqresURI;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class BasicAuthorization {
	
	@Test
	public void Test()
	{
	
	RequestSpecification req=new RequestSpecBuilder().setBaseUri("http://httpbin.org/digest-auth/undefined/saurabh/saurabh").build();
	
	//RequestSpecification res=given().spec(req).auth().basic("postman","password");
	
	RequestSpecification res=given().spec(req).auth().digest("saurabh", "saurabh1");
	
	ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200)
			.build();
	
	
	Response response=  res.when().get().then().spec(respec).extract().response();
	
	String responseString=response.asString();
	
	System.out.println(responseString);
	
	//JsonPath js=new JsonPath(responseString);
	}

}
