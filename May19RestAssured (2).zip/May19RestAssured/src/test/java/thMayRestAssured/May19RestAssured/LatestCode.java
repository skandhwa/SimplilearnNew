package thMayRestAssured.May19RestAssured;

import org.testng.annotations.Test;

import POJO.Details;
import POJO.PojoCourseCollection;
import POJO.course;
import POJO.location;

public class LatestCode {
	
	@Test
	public void TestCourseDetails()
	{
		PojoCourseCollection obj=new PojoCourseCollection();
		Details obj1=new Details();
		location obj2=new location();
		course obj3=new course();
		
		obj.setDegree("Btech");
		obj.setDetails(obj1);
		obj.setInstructor("Saurabh Kandhway");
		obj.setPurchaseAmount("8000");
		
		obj2.setCenter("Kolkata");
		obj2.setCost("5000");

		
		
		
		
		
	}
	

}
