package thMayRestAssured.May19RestAssured;

import URI.ReqresURI;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class StaticJsonExample {

	public static void main(String[] args) throws IOException {
		
		RestAssured.baseURI=ReqresURI.baseURI;
		
	String Response=	given().log().all().body(new String(Files.
				readAllBytes(Paths.get("C:\\Users\\saura\\OneDrive\\Desktop\\Simplilearn Rest Assured\\StaticBody.json"))))
		.when().post().then().statusCode(201).extract().response().asString();
				
		System.out.println(Response);
		
		
		
		
		

	}

}
