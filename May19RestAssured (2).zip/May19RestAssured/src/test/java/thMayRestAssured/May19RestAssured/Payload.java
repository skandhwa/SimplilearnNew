package thMayRestAssured.May19RestAssured;

public class Payload {
	
	public static String AddDetails()
	{
		return "{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}";
	}

}
