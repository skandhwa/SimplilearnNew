package POJO;

import java.util.List;


public class Details {
	
	private List<course> course;
	public List<course> getCourse() {
		return course;
	}
	public void setCourse(List<course> course) {
		this.course = course;
	}
	public List<location> getLocation() {
		return location;
	}
	public void setLocation(List<location> location) {
		this.location = location;
	}
	private List<location> location;

}
