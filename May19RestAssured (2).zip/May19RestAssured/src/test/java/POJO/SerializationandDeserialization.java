package POJO;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import URI.ReqresURI;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import thMayRestAssured.May19RestAssured.Payload;

public class SerializationandDeserialization {
	
	@Test
	public void createEmployee() throws JsonProcessingException
	{
		Employee emp=new Employee();
		emp.setFirstname("Manish");
		emp.setLastname("Agarwal");
		emp.setGender("male");
		emp.setAge(34);
		emp.setSalary(34500.65);
		
		ObjectMapper obj=new ObjectMapper();
		
		String employeeJson=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		System.out.println(employeeJson);
		
	RequestSpecification req=new RequestSpecBuilder().setBaseUri(ReqresURI.baseURIbin).setContentType(ContentType.JSON).setRelaxedHTTPSValidation().build();
		
		RequestSpecification res=given().spec(req).body(employeeJson);
		
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200)
				.expectContentType(ContentType.JSON).build();
		
		
		Response response=  res.when().post().then().spec(respec).extract().response();
		System.out.println(response);
String responseString=response.asString();
		
		System.out.println(responseString);
		
		System.out.println("----------------DOING DE SRIALIZATION-------------------");
		
		
		Employee emp2=obj.readValue(employeeJson, Employee.class);
		System.out.println(emp2.getFirstname());
		System.out.println(emp2.getLastname());
		System.out.println(emp2.getGender());
		System.out.println(emp2.getSalary());
		
		
		
		
		
	}

}
