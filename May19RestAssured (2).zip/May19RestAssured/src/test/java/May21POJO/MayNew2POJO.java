package May21POJO;

public class MayNew2POJO {
	
	private String name;

}
