package Test_Simplilearn;

public class TestNewStatic extends AT {

	public static void main(String[] args) {


		AT.display();

	}

}
