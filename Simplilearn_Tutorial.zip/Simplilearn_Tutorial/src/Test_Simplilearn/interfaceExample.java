package Test_Simplilearn;

interface ABCD
{
	void print();
	int x=9;
}

class XYZ implements ABCD
{
	public void print()
	{
		System.out.println("I am implementing");
	}
}

public class interfaceExample {

	public static void main(String[] args) {
		
		XYZ obj=new XYZ();
		obj.print();
		
		ABCD obj1=new XYZ();
		obj1.print();
		

	}

}
