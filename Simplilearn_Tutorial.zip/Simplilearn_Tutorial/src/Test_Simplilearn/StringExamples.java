package Test_Simplilearn;

public class StringExamples {

	public static void main(String[] args) {

         String T="Saurabh";///declaring String Through Literal
         
         String Y=new String("Welcome");//declaring String Through New Keyword
         
         String S2="Saurabh";
         
         ///concat
         
         String S3=S2.concat("Kandhway");
         
         System.out.println(S3);

	}

}
