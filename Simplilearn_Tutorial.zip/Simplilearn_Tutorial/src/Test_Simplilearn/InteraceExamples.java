package Test_Simplilearn;

interface Draw
{
	void draw();

}

interface Rectangle extends Draw
{
	void draw1();
}

class Diagram implements Rectangle,Draw
{
	public void draw()
	{
		System.out.println("This is draw method");///defination
	}
	public void draw1()
	{
		System.out.println("This is draw1 method");
	}
}


public class InteraceExamples {

	public static void main(String[] args) {
		
		Rectangle r1=new Diagram();
		r1.draw();
		r1.draw1();
		
		
		

	}

}
