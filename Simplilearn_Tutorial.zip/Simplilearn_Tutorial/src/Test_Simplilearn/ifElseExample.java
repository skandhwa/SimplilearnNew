package Test_Simplilearn;

public class ifElseExample {

	public static void main(String[] args) {
		
		int x=100;
		int y=15;
		int z=2;
		
		if(x>=y &&x>=z)///10>=15 && 10>=20
		{
			System.out.println("x is largest");
		}
		
		else if (y>=x && y>=z)///15>=10,15>=20
		{
			System.out.println("y is largest");
		}
		
		else
			System.out.println("z is largest");
				
		

	}

}
