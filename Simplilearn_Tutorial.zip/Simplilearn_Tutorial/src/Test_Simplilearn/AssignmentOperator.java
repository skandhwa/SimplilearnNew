package Test_Simplilearn;

public class AssignmentOperator {

	public static void main(String[] args) {
		
		int x=6;
		int z=2;
		
		z+=x;///z=z+x;
		 
		z-=x;//z=z-x;
		
		x+=z;//x=x+z
		
		
		
		
		
		
		
		
		

	}

}
