package Test_Simplilearn;

public class WhileLoop {

	public static void main(String[] args) {


		int i=0;
		do
		{
			System.out.println(i);//0
			i++;//1
		}
		
		while (i<5);//1<5//2<5

	}

}
