package Test_Simplilearn;

abstract class Bike
{
	abstract void run();
	
	void display()
	{
		System.out.println("Hello world");
	}	
}

class Honda extends Bike
{
	void run()
	{
		System.out.println("I am running");
	}
	
}


public class AbstractClass {

	public static void main(String[] args) {
		Bike obj=new Honda();
		obj.run();
		obj.display();

	}

}
