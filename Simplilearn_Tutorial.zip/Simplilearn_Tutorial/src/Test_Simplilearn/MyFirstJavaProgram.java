package Test_Simplilearn;

class ABC
{
	void M()
	{
		System.out.println("Test 1234");
	}
	
	
}



public class MyFirstJavaProgram {

	public static void main(String[] args) 
	
	{
		
		ABC obj=new ABC();
		obj.M();
		System.out.println("Hello World");

	}

}
