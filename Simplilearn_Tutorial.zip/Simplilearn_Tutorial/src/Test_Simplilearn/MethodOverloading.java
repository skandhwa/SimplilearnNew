package Test_Simplilearn;

class Add
{
	int add(int a,int b)
	{
		return a+b;
	}
	
	float add(int a,int b,int c)
	{
		return a+b+c;
	}
}

public class MethodOverloading {

	public static void main(String[] args) {
        
		Add obj=new Add();
		obj.add(12, 13);
		obj.add(12, 13, 14);
		


	}

}
