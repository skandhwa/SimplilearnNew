package Test_Simplilearn;

public class Operator {

	public static void main(String[] args) {
		
		int x=10;
		int y=20;
		int c=5;
		int d=8;
		x++;//postfix increment
		
		++x;//prefix increment
		
		x--;//postfix decrement
		
		--x;
		
		//int z= ++x + y-- - ++x - y++;////11+20-11-20
		
		//int z1= --x + --y + ++y + x++ - y++ + ++c; /// 9 + 19 +21 +9 -20+6
		
		int z2= x++ + --d + c++ + --x + ++d + --c + --y + ++d;
		
		//10 + 7 + 5 + 9 + 9 + 4 + 19 + 8
		
		///9+19+20+9-20+6
		
		System.out.println(z2);
		
		
		
		
		
		

	}

}
