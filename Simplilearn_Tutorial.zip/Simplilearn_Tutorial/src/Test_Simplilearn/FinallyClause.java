package Test_Simplilearn;

public class FinallyClause {

	public static void main(String[] args) {

		     try
		     {
             
		    	 int []a=new int[5];
		    	 a[0]=20;
		    	 a[1]=19;
		    	 a[2]=21;
		    	 a[3]=22;
		    	 a[4]=23;
		    	 //a[5]=56;
		    	 
		    	 for(int i=0;i<a.length;i++)
		    	 {
		    		 System.out.println(a[i]);
		    	 }
		    	 
		     }
		     catch(Exception e)
		     {
		    	 System.out.println("Caught");
		    	 
		     }
             
             finally
             {
            	 System.out.println("I will always execute");
             }

	}

}
