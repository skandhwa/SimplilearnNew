package Test_Simplilearn;

public class ForLoopExample {

	public static void main(String[] args) {
		
		for(int i=0;i<5;i++)//0 ,0<5,,1,,2
		{
			System.out.println(i);//0//1//2//3//4 
		}
		

	}

}
