package Test_Simplilearn;

public class MethodsofString {

	public static void main(String[] args) {
	
		
		String str="Saurabh";
		char ch=str.charAt(6);
		
		System.out.println(ch);
		
		int length=str.length();
		System.out.println(length);
		
		String sub=str.substring(3,6);
		System.out.println(sub);
		
		

	}

}
