package Test_Simplilearn;

public class ifLoopExample {

	public static void main(String[] args) {
		
		int x=10;
		int y=20;
		
		if(x>y)//100>20
		{
			System.out.println("x is largest");
		}
		
		else
		{
			System.out.println("y is largest");
		}
		

	}

}
