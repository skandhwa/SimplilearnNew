package Test_Simplilearn;

class AT
{
	static void display()
	{
		System.out.println("Hello");
	}
}

public class StaticExamples {

	public static void main(String[] args) {
		
		AT.display();
		
		

	}

}
