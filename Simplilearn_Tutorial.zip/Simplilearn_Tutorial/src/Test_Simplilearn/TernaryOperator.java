package Test_Simplilearn;

public class TernaryOperator {

	public static void main(String[] args) {
		
		
		int num1=10;
		int num2=20;
		
		int max;
		max= (num1>num2) ? num1:num2;///100>20
		System.out.println(max);

	}

}
