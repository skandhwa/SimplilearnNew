package Test_Simplilearn;

public class ThrowException {

	public static void main(String[] args) {

		
		int x=10;
		int y=x/0;
		throw new ArithmeticException("Trying to divide by zero");
		Thread.sleep(5000);
		
		
		//System.out.println("hello");


	}

}
