package Test_Simplilearn;

public class ArrayExamples {

	public static void main(String[] args) {

        int a[]=new int[5];
        
        
        int []b=new int[] {3,5,9,11,12};
        
        int c[]= {2,34,56,78,90};
        
        
        a[0]=12;
        a[1]=20;
        a[2]=40;
        a[3]=60;
        a[4]=80;
        
        for(int i=0;i<a.length;i++)///i=0;i<5//i=1//i=2
        {
        	System.out.println(a[i]);
        }
		
		

	}

}
