package Test_Simplilearn;

public class ExceptionExamples {

	public static void main(String[] args) {
        
		
		
		
//		try
//		{
//			int x=10;
//			int y=x/0;
//			System.out.println(y);
//		}
//		
//		catch(ArithmeticException e)
//		{
//			System.out.println("Exception caught");
//		}
		
		
		int a[]=new int[5];
		
		try
		{
		a[0]=12;
        a[1]=20;
        a[2]=40;
        a[3]=60;
        a[4]=80;
        a[5]=90;
        for(int i=0;i<a.length;i++)///i=0;i<5//i=1//i=2
        {
        	System.out.println(a[i]);
        }
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Exception caught");
		}
		
		
		System.out.println("Hello");
		

	}

}
