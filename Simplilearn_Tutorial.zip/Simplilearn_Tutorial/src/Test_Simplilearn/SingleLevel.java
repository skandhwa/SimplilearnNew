package Test_Simplilearn;

class A              ////parent class or super class
{
	void display()
	{
		System.out.println("Hello world");
	}
}

class B extends A      ///B is child class and A is parent class
{
	void display1()
	{
		System.out.println("Hello world123");
	}
}

class C extends B
{
	void display2()
	{
		System.out.println("Hello world123456");
	}
}



public class SingleLevel {

	public static void main(String[] args) {
		
		C obj=new C();
		obj.display();
		obj.display1();
		obj.display2();
		
		

	}

}
