package Test_Simplilearn;

public class CharacterArray {

	public static void main(String[] args) {


		char []a= new char[5];
		
		a[0]='J';
		a[1]='A';
		a[2]='V';
		a[3]='A';

	}

}
