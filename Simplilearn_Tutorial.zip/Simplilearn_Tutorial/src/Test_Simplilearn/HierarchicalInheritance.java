package Test_Simplilearn;

class AZ
{
	void display()
	{
		System.out.println("Hello world");
	}
}

class BZ extends AZ
{
	void display1()
{
	System.out.println("Hello world1234");
}
}
	
class CZ extends AZ
{
	void display2()
{
	System.out.println("Hello world1234seewrew");
}
	
}

public class HierarchicalInheritance {

	public static void main(String[] args) {
		
		BZ obj=new BZ();
		obj.display1();
		CZ obj1=new CZ();
		obj1.display2();
		

	}

}
