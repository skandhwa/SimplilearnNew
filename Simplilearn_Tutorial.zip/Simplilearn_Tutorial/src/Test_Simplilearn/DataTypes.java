package Test_Simplilearn;

public class DataTypes {

	public static void main(String[] args) {
		
		boolean flag=true;
		int x=7;
		float y=7.8735f;
		double g=2343242304203984029384.328463287468327648723648326842;
		char ch='T';
		
		String str="Saurabh";
		int []a=new int[] {1,2,3,4,5};
		
		
		
		

	}

}
