package Test_Simplilearn;

public class MaxNumberFromArray {

	public static void main(String[] args) {


		 int c[]= {61,12,87,14,24};
		 int max;
		 max=c[0];
		 
		 for(int i=0;i<c.length;i++)///0,,0<5//1//2
		 {
			 if(c[i]>max)///
			 {
				 max=c[i];
			 }
			 
		 }
		 
		 System.out.println(max);
		 

	}

}
