package Test_Simplilearn;

class Bank
{
	int getintrest()
	{
		return 0;
	}
}

class SBI extends Bank
{
	int getintrest()
	{
		return 8;
	}
}
class Axis extends Bank
{
	int getintrest()
	{
		return 10;
	}
}

public class MethodOverriding {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
		obj.getintrest();
		Axis obj1=new Axis();
		obj1.getintrest();
		
		

	}

}
