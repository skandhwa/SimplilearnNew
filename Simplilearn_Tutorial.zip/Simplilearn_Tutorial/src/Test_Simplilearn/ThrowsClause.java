package Test_Simplilearn;

import java.io.FileNotFoundException;
import java.io.IOException;

class AX
{
	void M() throws IOException
	{
		throw new IOException("deviceerror");
	}
	
	void N() throws FileNotFoundException
	{
		throw new FileNotFoundException("Arithemtic");
	}
}

public class ThrowsClause {

	public static void main(String[] args) throws InterruptedException {
       
		Thread.sleep(5000);
		

	}

}
