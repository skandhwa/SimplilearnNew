package Test_Simplilearn;

interface AW
{
	void display();
}

interface AY extends AW
{
	void display1();
}

class AR implements AW,AY
{
	public void display()
	{
		System.out.println("Hello");
	}
	public void display1()
	{
		System.out.println("Hello world");
	}
}

public class Interface2 {

	public static void main(String[] args) {
		
		AY obj=new AR();
		obj.display();
		obj.display1();
		
		
		

	}

}
