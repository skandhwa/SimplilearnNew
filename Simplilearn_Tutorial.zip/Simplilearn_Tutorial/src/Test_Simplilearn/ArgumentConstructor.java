package Test_Simplilearn;

class Student
{
	int id;
	String name;
	
	Student(int i,String n)
	{
		id=i;
		name=n;		
	}
	
	void display()
	{
		System.out.println(id+"  "+name);
	}

}
public class ArgumentConstructor {

	public static void main(String[] args) {
		
		Student obj1=new Student(111,"Saurabh");
		Student obj2=new Student(117,"Samir");
		obj1.display();
		obj2.display();
				

	}

}
