package Test_Simplilearn;

public class Arithmetic {

	public static void main(String[] args) {
		
		int x=16 ;
		int y=20;
		int z=15;
		
		if(x>y || x>z)///16>20 && 16>15
		{
			System.out.println("Hello");
		}
		
		else
			
			System.out.println("Not welcome");

	}

}
