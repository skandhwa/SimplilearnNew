package StepDefinition;

import PageFactoryElements.LoginPage;
import Utilities.DriverInitialization;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class stepDefinition {
	
	LoginPage obj=new LoginPage(DriverInitialization.getDriver());
	
	
	@Given("User opens the WebPage")
	public void user_opens_the_web_page() 
	{
	    System.out.println("Application Launched and working fine");
	}

	@Then("User Enters FirstName")
	public void user_enters_first_name() {
		
		obj.loginApplication();
		
	    
	}

	@Then("User Enters LastName")
	public void user_enters_last_name() {
		obj.loginApplicationlastname();
		
		
	    
	}
	
	
	@Then("User Enters {string}")
	public void user_enters(String address) 
	
		
		{
			obj.enterAddress(address);
		}
		
	    
	


	

}
