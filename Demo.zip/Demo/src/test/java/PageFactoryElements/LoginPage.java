package PageFactoryElements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Actions.ActionNew;

public class LoginPage {
	
	ActionNew obj1=new ActionNew();
	
	
	public LoginPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//input[@id='vfb-5']")
	WebElement firstname;
	
	@FindBy(xpath="//input[@id='vfb-7']")
	WebElement lastname;
	
	@FindBy(xpath="//input[@id='vfb-13-address']")
	WebElement address;
	
	
	
	public void loginApplication()
	{
		firstname.sendKeys("Saurabh");
		obj1.ScrollDown();
	}
	
	
	public void loginApplicationlastname()
	{
		lastname.sendKeys("Kandhway");
	}
	
	
	public void enterAddress(String text3)
	{
		address.sendKeys(text3);
	}

}
