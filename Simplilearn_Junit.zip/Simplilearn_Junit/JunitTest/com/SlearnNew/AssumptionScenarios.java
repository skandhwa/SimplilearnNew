package com.SlearnNew;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

class AssumptionScenarios {

	@Test
	void AssumeNew() {
		
		assumeTrue("DEV".equals(System.getProperty("ENV")));
		System.out.println("assumption passed");
		assertEquals(3,2+1);
		
	}
	
	@Test
	
void AssumewithMessage() {
		
		assumeTrue("QA".equals(System.getProperty("ENV")),"Assumption Failed");
		System.out.println("assumption passed for second");
		assertEquals(3,2+1);
		
	}

}
