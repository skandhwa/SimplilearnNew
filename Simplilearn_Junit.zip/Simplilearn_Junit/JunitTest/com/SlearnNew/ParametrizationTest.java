package com.SlearnNew;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.EnumSource.Mode;
import org.junit.jupiter.params.provider.ValueSource;

public class ParametrizationTest {
	
	@ParameterizedTest(name="{index}-Run test with args={0}")
	@ValueSource(ints= {1,3,5,7,})
	public void  valuesourcetest(int args)
	{
		System.out.println(args);
	}
	
	
	
	
	
	
	@ParameterizedTest(name="{index}-Run test with args={0}")
	@ValueSource(strings= {"apple","banana","pineapple","melon",})
	public void  valuesourcetest2(String fruit)
	{
		System.out.println(fruit);
	}


	
	
	
	
	

enum Fruits
{
	apple,banana,pineapple,melon;
}


@ParameterizedTest(name="{index}-Run test with args={0}")
@EnumSource(Fruits.class)
public void  enumsourcetest2(Fruits fruit)
{
	System.out.println(fruit);
}



@ParameterizedTest(name="{index}-Run test with args={0}")
@EnumSource(value=Fruits.class, mode=Mode.EXCLUDE,names= {"banana","melon"})
public void  enumsourcetest3(Fruits fruit)
{
	System.out.println(fruit);
}

}







