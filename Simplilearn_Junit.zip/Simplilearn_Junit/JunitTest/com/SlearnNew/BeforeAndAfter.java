package com.SlearnNew;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;


@TestInstance(Lifecycle.PER_CLASS)
public class BeforeAndAfter {
	
	
	
	@BeforeAll
	public void test1()
	{
		System.out.println("Hello");///y
	}
	
	@AfterAll
	public void test2()
	{
		System.out.println("Hello I am After all");///c
	}
	
	@BeforeEach
	public void test3()
	{
		System.out.println("Hello I am Before each");///d
	}
	
	@AfterEach
	public void test4()
	{
		System.out.println("Hello I am After each");///e
	}
	
	@Test
	public void test5()
	{
		System.out.println("Hello I am first Test");///f
	}
	@Test
	public void test6()
	{
		System.out.println("Hello I am second Test");///g
	}
	

}
