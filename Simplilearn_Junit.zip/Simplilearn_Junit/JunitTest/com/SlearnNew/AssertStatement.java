package com.SlearnNew;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class AssertStatement {
	
	 @Test
	   public void testAssertions() {
	      //test data
	      String str1 = new String ("abc");
	      String str2 = new String ("abc");
	      String str3 = null;
	      String str4 = "abc";
	      String str5 = "abc";
			
	      int val1 = 5;
	      int val2 = 6;

	      String[] expectedArray = {"one", "two", "three"};
	      String[] resultArray =  {"one", "two", "three"};

	      //Check that two objects are equal
	      assertEquals(str1, str2);
	      System.out.println("String results are passed");

	      //Check that a condition is true
	      assertTrue (val1 < val2);
	      System.out.println("Two values are same passed");

	      //Check that a condition is false
	      assertFalse(val1 > val2);
	      System.out.println("Two values are not same");

	      //Check that an object isn't null
	      assertNotNull(str1);
	      System.out.println("String is not null");

	      //Check that an object is null
	      assertNull(str3);
	      System.out.println("String is  null");

	      //Check if two object references point to the same object
	      assertSame(str4,str5);
	      System.out.println("Both the String are same");

	      //Check if two object references not point to the same object
	      assertNotSame(str1,str3);
	      System.out.println("Both the String are not same");

	      //Check whether two arrays are equal to each other.
	      assertArrayEquals(expectedArray, resultArray);
	      System.out.println("Both the array are same");
	   }

}
