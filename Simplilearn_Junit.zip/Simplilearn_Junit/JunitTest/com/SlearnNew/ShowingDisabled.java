package com.SlearnNew;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class ShowingDisabled {

	@Test
	@Disabled
	void test() {
		fail("Hello");
	}
	
	@Test
	void test1() {
		System.out.println("Hello New");
	}
	
	

}
