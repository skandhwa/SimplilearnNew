package com.SlearnNew;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeFalse;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

class AssumeFalsemethod {

	@Test
	public void AssumeFalseMethodNew()
	{
		assumeFalse("DEV".equals(System.getProperty("ENV")),"Assumption passed");
		System.out.println("assumption passed");
		assertEquals(3,2+1);
		
	}

}
