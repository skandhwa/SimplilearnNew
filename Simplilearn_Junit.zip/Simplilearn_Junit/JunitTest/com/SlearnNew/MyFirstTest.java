package com.SlearnNew;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MyFirstTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
