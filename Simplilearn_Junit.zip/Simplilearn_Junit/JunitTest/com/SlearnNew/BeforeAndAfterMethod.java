package com.SlearnNew;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;


@TestInstance(Lifecycle.PER_METHOD)
public class BeforeAndAfterMethod {
	
	

	
	@BeforeAll
	public static void test1()
	{
		System.out.println("Hello");
	}
	
	
	
	@AfterAll
	public static void test2()
	{
		System.out.println("Hello I am After all");
	}
	
	@BeforeEach
	public void test3()
	{
		System.out.println("Hello I am Before each");
	}
	
	@AfterEach
	public void test4()
	{
		System.out.println("Hello I am After each");
	}
	
	@Test
	public  void test5()
	{
		System.out.println("Hello I am first Test");
	}
	@Test
	public  void test6()
	{
		System.out.println("Hello I am second Test");
	}

}
