package TESTNGSLEARN.TESTNGTutorial;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProvidersMethodExample {
	
	
	@DataProvider(name="data-provider")
	public Object[][] dpmethod(Method m)
	{
		switch(m.getName())
		
		{ 
		case "Sum":
			return new Object[][] {{2,3,5},{5,7,12}};
			
		case "diff":
			return new Object[][] {{20,3,17},{50,7,43}};
		
		}
		return null;
		
	}
		@Test(dataProvider="data-provider")
		public void Sum(int a,int b,int result)
		{
			int finalsum=a+b;
			Assert.assertEquals(result,finalsum);
			
		}
			
			@Test(dataProvider="data-provider")
			public void diff(int a,int b,int result)
			{
				int finaldiff=a-b;
				Assert.assertEquals(result,finaldiff);
			
			
		
		
		
		
		
		
	}
	}
	

