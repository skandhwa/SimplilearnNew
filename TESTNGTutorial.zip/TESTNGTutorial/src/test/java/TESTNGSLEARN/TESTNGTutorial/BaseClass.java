package TESTNGSLEARN.TESTNGTutorial;

public class BaseClass {
	
	
	

}
