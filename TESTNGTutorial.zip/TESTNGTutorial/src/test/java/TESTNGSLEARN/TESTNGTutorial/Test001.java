package TESTNGSLEARN.TESTNGTutorial;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test001 {
	public static WebDriver driver;
	
	@Test(retryAnalyzer=TESTNGSLEARN.TESTNGTutorial.RetryAnalyzer.class)
	public void test1()
	{
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		Assert.assertEquals("Google",title);
		
	}
	
	@Test(retryAnalyzer=TESTNGSLEARN.TESTNGTutorial.RetryAnalyzer.class)
	public void test2()
	{
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.flipkart.com/");
		String title1=driver.getTitle();
		Assert.assertEquals("Google123",title1);
		
	}
	
	

}
