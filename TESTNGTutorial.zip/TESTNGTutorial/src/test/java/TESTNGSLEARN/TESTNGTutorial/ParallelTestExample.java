package TESTNGSLEARN.TESTNGTutorial;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ParallelTestExample {
	
	public WebDriver driver;
	
	@Test
	public void openChrome()
	{
		System.out.println("Thread Id is" +Thread.currentThread().getId());
		
		driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		
	}
	
	
	@Test
	public void OpenFirefox()
	{
		System.out.println("Thread Id is" +Thread.currentThread().getId());
		driver=new FirefoxDriver();
		driver.get("https://www.flipkart.com/");
	}
	
	
	@Test
	public void OpenEdge()
	{
		System.out.println("Thread Id is" +Thread.currentThread().getId());
		driver=new EdgeDriver();
		driver.get("https://www.flipkart.com/");
	}
	

}
