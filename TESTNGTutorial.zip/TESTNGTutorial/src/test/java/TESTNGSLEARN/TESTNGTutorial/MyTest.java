package TESTNGSLEARN.TESTNGTutorial;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;



@Listeners(TESTNGSLEARN.TESTNGTutorial.ListenerNew.class)

public class MyTest {
	public static WebDriver driver;
	
	@Test
	public void OpenBrowser()
	{
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		Assert.assertEquals("Google123",title);
	}
	
	
	@Test
	public void TestNew()
	{
		Assert.assertEquals(5,5);
	}
	
	public static void takescreenshot() throws IOException
	{
		TakesScreenshot srcshot=(TakesScreenshot) driver;
		File SrcFile=srcshot.getScreenshotAs(OutputType.FILE);
		
		
		String path="C:\\Users\\saura\\OneDrive\\Pictures\\ScreenShot on Failure\\FailedwithLogging.png";
		
		File DestFile= new File(path);
		FileUtils.copyFile(SrcFile, DestFile);
		Reporter.log("The test case has failed and screenshot is kept at" +path);
		
	}
	
	
	
	

}
