package TESTNGSLEARN.TESTNGTutorial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserTesting {
	
	public WebDriver driver;
	
	@Parameters("browser")
	@BeforeClass
	public void beforeTest(String Browser)
	{
		if(Browser.equalsIgnoreCase("firefox"))
			driver=new FirefoxDriver();
		else if(Browser.equalsIgnoreCase("chrome"))
			driver=new ChromeDriver();
		else if(Browser.equalsIgnoreCase("edge"))
			driver=new EdgeDriver();
		
		
		
		driver.get("https://nxtgenaiacademy.com/demo-site/");
	}
	
	@Test()
	public void openGmail() throws InterruptedException
	{
		 
		 driver.manage().window().maximize();
	     WebElement ele1=driver.findElement(By.xpath("//input[@id='vfb-5']"));
	    boolean flag= ele1.isDisplayed();
	    System.out.println(flag);
	     
	     driver.findElement(By.xpath("//input[@id='vfb-5']")).sendKeys("Saurabh");
	     Thread.sleep(4000);
	     driver.findElement(By.xpath("//input[@id='vfb-5']")).clear();
		
		
		
	}
	
	
	

}
