package TESTNGSLEARN.TESTNGTutorial;

import org.testng.annotations.Test;

public class TestNgEnabled {
	
	@Test
	public void test()
	{
		System.out.println("Hello");
	}
	
	
	@Test()
	public void abc()
	{
		System.out.println("Hello I am abc method");
	}
	
	
	@Test(enabled=false)
	public void abcd()
	{
		System.out.println("Hello I am abcd");
	}
	
	

}
