package TESTNGSLEARN.TESTNGTutorial;

import org.testng.annotations.Test;

public class TestNgGroups {
	
	@Test(groups= {"sanity"})
	public void test1()
	{
		System.out.println("I am executing sanity scenarios");
	}
	
	
	@Test(groups= {"sanity"})
	public void test2()
	{
		System.out.println("I am executing another sanity scenarios");
	}
	
	
	@Test(groups= {"regression"})
	public void test3()
	{
		System.out.println("I am executing regression scenarios");
	}
	
	@Test(groups= {"smoke"})
	public void test4()
	{
		System.out.println("I am executing smoke scenarios");
	}
	
	
	

}
