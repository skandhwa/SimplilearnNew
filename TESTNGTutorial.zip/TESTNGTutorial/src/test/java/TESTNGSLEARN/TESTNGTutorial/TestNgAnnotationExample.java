package TESTNGSLEARN.TESTNGTutorial;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNgAnnotationExample {
	
	
	
	@BeforeTest
	public void test1()
	{
		System.out.println("I am BeforeTest");/////1
	}
	
	@AfterSuite
	public void test2()
	{
		System.out.println("I am After Suite");////5
	}
	
	@AfterMethod
	public void test4()
	{
		System.out.println("I am After Method");////3
	}
	
	@AfterClass
	public void test5()
	{
		System.out.println("I am After Class");////4
	}
	
	
	@Test
	public void test6()
	{
		System.out.println("I am Test");////2
	}


}
