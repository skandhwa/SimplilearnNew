package TESTNGSLEARN.TESTNGTutorial;

import org.testng.annotations.Test;

public class SecondTest {
	
	@Test
	public void test123()
	{
		System.out.println("Hello World");
	}
	
	@Test
	public void test123New()
	{
		System.out.println("Hello World How are you");
	}

}
