package TESTNGSLEARN.TESTNGTutorial;

import org.testng.annotations.Test;

public class TestNgPriorityExamples {
	
	@Test(priority=0)
	public void test()
	{
		System.out.println("Hello");
	}
	
	
	@Test(priority=-3)
	public void abc()
	{
		System.out.println("Hello I am abc method");
	}
	@Test()
	public void abcd()
	{
		System.out.println("Hello I am abcd");
	}
	
	
	
	@Test(priority=1)
	public void xyz()
	{
		System.out.println("Hello I am xyz method");
	}
	

}
