package TESTNGSLEARN.TESTNGTutorial;

import org.junit.Assert;
import org.testng.annotations.Test;

public class DependentTest {
	
	@Test
	public void openBrowser()
	{
		Assert.assertEquals(3,5);
		System.out.println("Hello");
	
	}
	
	@Test()
	public void Login()
	{
		System.out.println("Hello I am login functionality");
		Assert.assertEquals(5,5);
		
	}
	
	@Test(dependsOnMethods= {"Login","openBrowser"}, alwaysRun=true)
	public void SearchaProduct()
	{
		System.out.println("Hello I am Search Product  functionality");
	}


}
