package TESTNGSLEARN.TESTNGTutorial;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



public class TestNgdataProviders {
	
	@DataProvider(name="data-provider")
	public Object[][] dpmethod()
	{
		return new Object[][] {{2,3,5},{4,5,2}};
	}
	
	
	@Test(dataProvider="data-provider")
	public void mytest(int a,int b,int result)
	{
		int sum=a+b;
		Assert.assertEquals(result,sum);
		
		
	}
	
	
	

}
