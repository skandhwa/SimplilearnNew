package TESTNGSLEARN.TESTNGTutorial;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgInvokations {
	
	public  WebDriver driver;
	
	@Test(timeOut=50000,invocationCount=4)
	public void test() throws InterruptedException
	{
		driver=new ChromeDriver();
		Thread.sleep(2000);
		driver.get("https://www.google.com/");
	}

}
