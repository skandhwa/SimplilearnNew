package TESTNGSLEARN.TESTNGTutorial;

import org.testng.annotations.Test;

public class FirstTest {
	
	@Test
	public void test123()
	{
		System.out.println("Hello");
	}

	@Test
	public void abc()
	{
		System.out.println("Hello New");
	}
	
	
	@Test
	public void abcd()
	{
		System.out.println("Hello New I am latest");
	}
	
}
