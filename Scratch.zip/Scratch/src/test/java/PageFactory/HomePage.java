package PageFactory;

public class HomePage {
	
	public static String getFirstName()
	{
		String name="//input[@id='vfb-5']";
		return name;
	}
	
	public static String getLastName()
	{
		String lastname="//input[@id='vfb-7']";
		return lastname;
	}

}
