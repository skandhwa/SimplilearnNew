package Utilities;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import Constants.Constants;

public class ReadDatafromProperty {
	
	Constants obj=new Constants();
	
	public Properties  ReadDataProperty() throws IOException
	{
		
		
		FileReader reader=new FileReader(obj.PROPERTYFILEPATH);
		Properties prop=new Properties();
		prop.load(reader);
		return prop;
		
		
		
	}

}
