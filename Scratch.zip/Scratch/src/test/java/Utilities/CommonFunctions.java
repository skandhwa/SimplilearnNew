package Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Constants.Constants;
import resources.TestCaseExecution;

public class CommonFunctions extends TestCaseExecution {
	
	Constants obj1=new Constants();
	
	
	public void scrolldown()
	{
		JavascriptExecutor js=(JavascriptExecutor) (driver);
		js.executeScript("windows.scrollBy(0,500)","");
		
	}
	
	public void takescreenshot() throws IOException
	{
		TakesScreenshot srcshot=(TakesScreenshot) driver;
		File Srcfile= srcshot.getScreenshotAs(OutputType.FILE);
		File DestFile=new File(Constants.SCREENSHOTPATH);
		FileUtils.copyFile(Srcfile, DestFile);
		
	}

} 
