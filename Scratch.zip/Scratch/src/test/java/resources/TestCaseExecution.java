package resources;

import java.awt.Dimension;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ExtentReportNew.ExtentTestReport;
import PageFactory.HomePage;
import Utilities.CommonFunctions;
import Utilities.GetDataFromExcel;
import Utilities.ReadDatafromProperty;
@Listeners(Utilities.ListenerNew.class)
public class TestCaseExecution extends ExtentTestReport {
	//CommonFunctions obj2=new CommonFunctions();
	
	
	GetDataFromExcel obj=new GetDataFromExcel();
	HomePage obj1=new HomePage();
	ReadDatafromProperty obj3=new ReadDatafromProperty();
	
	
	
	public static WebDriver driver=new ChromeDriver();
	

	@BeforeTest
	public void openBrowser() throws IOException
	{
		String Browsername=obj3.ReadDataProperty().getProperty("browser");
		if(Browsername.contains("chrome"))
		
		{
		
		
		try {
			driver.get(obj.getUrl());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.manage().window().maximize();
		
		
		
		
	}
	}
	
	@Test
	public void executeTest() throws IOException
	{
		ConfigReport();
		CreateTest();
		
		String FirstName=obj3.ReadDataProperty().getProperty("firstname");
		String LastName=obj3.ReadDataProperty().getProperty("lastname");
		driver.findElement(By.xpath(obj1.getFirstName())).sendKeys(FirstName);
		driver.findElement(By.xpath(obj1.getLastName())).sendKeys(LastName);
		
		
	}
	
	@AfterTest
	
	public void TestComplete()
	{
		FlushTest();
	}
	
	
	
	
	
	
	

}
