package Constants;

public class Constants {
	
	public static final String TESTDATA="D:\\TestData15thApril.xlsx";
	public static final String SCREENSHOTPATH="D:\\15thAprilScreenshots\\"+Math.random()+"test.png";
	public static final String PROPERTYFILEPATH="C:\\Users\\saura\\Downloads\\Simplilearn\\Scratch\\src\\main\\java\\Constants\\GlobalData.properties";
	public static final String EXTENTREPORTPATH=System.getProperty("user.dir")+ "\\test-output\\ExtentReport.html" ;
	

}
