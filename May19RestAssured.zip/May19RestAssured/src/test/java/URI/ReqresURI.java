package URI;

public class ReqresURI {
	
	public static final String baseURI="https://reqres.in/api/users";
	public static final String baseURIDelete="https://reqres.in/api/users/2";
}
