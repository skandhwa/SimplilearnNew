package thMayRestAssured.May19RestAssured;

import URI.ReqresURI;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;

public class QueryParamExplain {

	public static void main(String[] args) {
		RestAssured.baseURI=ReqresURI.baseURI;
		
		String Response=given().log().all().queryParam("page", "2").
	    when().get().then().statusCode(200).extract().response().asString();
		
		System.out.println(Response);

}
	
}
