package thMayRestAssured.May19RestAssured;

import static io.restassured.RestAssured.given;

import URI.ReqresURI;
import io.restassured.RestAssured;

public class DeleteMethod {

	public static void main(String[] args) {
		
		RestAssured.baseURI=ReqresURI.baseURIDelete;
		
		String Response=given().log().all()
.when().delete()
	.then().statusCode(204).header("Server","cloudflare")
	.extract().response().asString();

System.out.println(Response);
		

	}

}
