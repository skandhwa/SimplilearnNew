package thMayRestAssured.May19RestAssured;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;

public class RealTimeTestCases {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(Payloaddata.PayloadNew.CoursePrice());
		
		///print the number of courses returned by API
		
		int count=js.get("courses.size()");
		System.out.println("the total number of courses are  " +count);
		
		///.Print Purchase Amount
		
		int Amount=js.getInt("dashboard.purchaseAmount");
		System.out.println("the total amount is  " +Amount);
		
		/// Print Title of the first course
		
		String Titlefirstcourse=js.getString("courses[1].title");
		System.out.println("the title of first course is  " +Titlefirstcourse);
		
		
		//Print All course titles and their respective Prices
		
		for(int i=0;i<count;i++)///i=0,0<3,3<3
		{
			String Coursetitle=js.get("courses["+i+"].title");//course[0].title//
			System.out.println(Coursetitle);
			
			int price=js.get("courses["+i+"].price");///courses[0].price//
			System.out.println(price);
			
		}
		
		
		///Print no of copies sold by RPA Course
		System.out.println("The total number of copies sold by RPA course");
		for(int i=0;i<count;i++)///i=0,0<3,3<3
		{
			String Coursetitle=js.get("courses["+i+"].title");
			if(Coursetitle.equalsIgnoreCase("Cypress"))
			{
				int copies=js.get("courses["+i+"].copies");
				System.out.println(copies);
			
			}
			
		}
	
		
		//Verify if Sum of all Course prices matches with Purchase Amount
		int sum=0;
		
		for(int i=0;i<count;i++)///i=0,0<3,3<3
		{
			int copies=js.get("courses["+i+"].copies");
			int price=js.get("courses["+i+"].price");
			int amount=price*copies;
			//System.out.println(amount);
			sum=sum+amount;
		
		}
		System.out.println(sum);
		
		Assert.assertEquals(Amount, sum);
		System.out.println("Amount got matched");
			
		
		

	}

}
