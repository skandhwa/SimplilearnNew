package thMayRestAssured.May19RestAssured;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;

import URI.ReqresURI;

public class RestAssuredPostmethods {

	public static void main(String[] args) {
		
		RestAssured.baseURI=ReqresURI.baseURI;
		
	String Response=	given().log().all()
			
			.body(Payload.AddDetails()).headers("Content-Type","application/json")
		
		.when().post()
		.then().statusCode(201).headers("Content-Type","application/json; charset=utf-8")
		.extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
	String Createddate=js.getString("createdAt");
	System.out.println(Createddate);
	String []Word=Createddate.split(":");
	
	System.out.println(Word[0]);
	
	if(Word[0].contains("2023-05-19")==true)
	{
		System.out.println("This is a passscenario");
		
	}
	else
		System.out.println("This is a fail scenario");
	
	
	//given().relaxedHTTPSValidation().log()
	
	
	
	
	
		

	}

}
