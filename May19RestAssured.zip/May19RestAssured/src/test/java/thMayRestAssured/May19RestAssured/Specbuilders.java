package thMayRestAssured.May19RestAssured;

import URI.ReqresURI;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.given;

public class Specbuilders {

	public static void main(String[] args) {
		
		RequestSpecification req=new RequestSpecBuilder().setBaseUri(ReqresURI.baseURI).setContentType(ContentType.JSON).setRelaxedHTTPSValidation().build();
		
		RequestSpecification res=given().spec(req).body(Payload.AddDetails());
		
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(201)
				.expectContentType(ContentType.JSON).build();
		
		
		Response response=  res.when().post().then().spec(respec).extract().response();
		
		String responseString=response.asString();
		
		System.out.println(responseString);
		
		JsonPath js=new JsonPath(responseString);
		
		
		
		
		
		
		
		
		
		
		

	}

}
